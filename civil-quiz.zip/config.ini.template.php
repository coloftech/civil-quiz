;<?php exit(); ?>
[database]
hostname = %hostname%
username = %username%
password = %password%
dbname = %dbname%
dbprefix = q_


[dir]
upload = public
system = system
application = application

[urls]
base_url = 'http://civil-quiz'
site_url = 

[installation]
installed = '%installed%'