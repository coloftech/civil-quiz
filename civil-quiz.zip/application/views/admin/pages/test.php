<center>
<div class="col-md-12">
	<img src="http://i.imgur.com/zKfGtD7.jpg" width="140" height="200">
	<p><h5>Dioscoro A. Avergonzado</h5>
		<i>OIC University President</i></p>
</div>
<div class="col-md-6"><img src="http://i.imgur.com/4Hz7OS1.jpg" width="140" height="200">
	<p><h5>Atty. Joel D. Zamora</h5>
		<i>Vice-President, ABA</i></p></div>
<div class="col-md-6"><img src="http://i.imgur.com/irab07l.jpg" width="140" height="200">
	<p><h5>Dr. Regucivilla A. Pobar</h5>
		<i>Vice-President, ARA</i></p></div>
</center>

<center>
<div class="col-md-4"><img src="http://i.imgur.com/tPdsGDk.jpg" width="140" height="200">
	<p><h5>Atty. Joel D. Zamora</h5>
		<i>Vice-President, ABA</i></p></div>
<div class="col-md-4"><img src="http://i.imgur.com/qXPQgAD.jpg" width="140" height="200">
	<p><h5>Dr. Regucivilla A. Pobar</h5>
		<i>Vice-President, ARA</i></p></div>

<div class="col-md-4"><img src="http://i.imgur.com/oIqW4NX.jpg" width="140" height="200">
	<p><h5>Dr. Regucivilla A. Pobar</h5>
		<i>Vice-President, ARA</i></p></div>
		
<div class="col-md-4"><img src="http://i.imgur.com/5ARRF3h.jpg" width="140" height="200">
	<p><h5>Atty. Joel D. Zamora</h5>
		<i>Vice-President, ABA</i></p></div>
<div class="col-md-4"><img src="http://i.imgur.com/bmqlLLj.jpg" width="140" height="200">
	<p><h5>Dr. Regucivilla A. Pobar</h5>
		<i>Vice-President, ARA</i></p></div>

<div class="col-md-4"><img src="http://i.imgur.com/DBd0Fkt.jpg" width="140" height="200">
	<p><h5>Dr. Regucivilla A. Pobar</h5>
		<i>Vice-President, ARA</i></p></div>
</center>