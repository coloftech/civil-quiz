<style type="text/css">
.panel > .panel-body.panel-choices label{cursor:pointer;font-weight: normal;font-size: 13px;}
</style>
<?php
//print_r($list_exam);

if(isset($list_exam) && is_array($list_exam)){
	$i = 1;$j=1;
		$category = 0;
?>
<?php foreach ($list_exam as $key): ?>

	<?php
		
		if ( $category != (int)$key->category_id) {
			$category = $key->category_id;
			?>
			<h3>Test <?php echo $j; ?> - <?php echo $this->quiz_m->getCategoryName($key->category_id); ?></h3><br />

			<?php
			 $j++;
		}
	?>
	
	<div class="panel panel-default">
		<div class="panel-heading panel-question">
			<?php echo "<span style='display: inline-block;font-weight:bold;font-size:15px;'>$i)</span> <span style='display: inline-block;font-weight:bold;font-size:15px;'>$key->question_title </span>"; ?>
				
		</div>
		<div class="panel-body panel-choices">
			<p>
				<label for="choice_1_<?=$key->question_id;?>"><input type="radio" name="answer_<?=$key->question_id;?>" id="choice_1_<?=$key->question_id;?>" class="radio radio-inline"> <?=$key->choice_1?></label>
			</p>

			<p>
				<label for="choice_2_<?=$key->question_id;?>"><input type="radio" name="answer_<?=$key->question_id;?>" id="choice_2_<?=$key->question_id;?>" class="radio radio-inline"> <?=$key->choice_2?></label>
			</p>

			<p>
				<label for="choice_3_<?=$key->question_id;?>"><input type="radio" name="answer_<?=$key->question_id;?>" id="choice_3_<?=$key->question_id;?>" class="radio radio-inline"> <?=$key->choice_3?></label>
			</p>

			<p>
				<label for="choice_4_<?=$key->question_id;?>"><input type="radio" name="answer_<?=$key->question_id;?>" id="choice_4_<?=$key->question_id;?>" class="radio radio-inline"> <?=$key->choice_4?></label>
			</p>

			<p>
				<label for="choice_5_<?=$key->question_id;?>"><input type="radio" name="answer_<?=$key->question_id;?>" id="choice_5_<?=$key->question_id;?>" class="radio radio-inline"> <?=$key->choice_5?></label>
			</p>
		</div>
	</div>
<?php endforeach ?>

<?php

}

;?>