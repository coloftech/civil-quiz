<div class="panel panel-info">
	<div class="panel-heading">Your result</div>
	<div class="panel-body">
		<?php echo $results; ?>
	</div>
</div>