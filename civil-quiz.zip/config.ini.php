;<?php exit(); ?>
[database]
hostname = localhost
username = root
password = 
dbname = coloftec_quize
dbprefix = q_


[dir]
upload = public
system = system
application = application

[urls]
base_url = 'http://civil-quiz'
site_url = 

[installation]
installed = 'on'