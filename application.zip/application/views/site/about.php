<div class="wrapper site-wrapper">
	<div class="container site-container">
		<h4>About</h4>

		<?=isset($about) ? $about : ''; ?>
	</div>
</div>