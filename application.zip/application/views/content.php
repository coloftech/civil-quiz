
<div class="col-md-9 post-content">
	<div class="item" id="post-sticky">
		<div class="col-md-3 featured-img-s"><a href=""><img src="public/images/android.png"></a></div>

		<div class="col-md-9 post-desc-home">
		<a href="#" class="post-title-home">THis is the title</a>
		thisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the caption ende nedn eeeeeeeeee eeeeeeeeeeeee eeeeeeeeeeeeeeeee  eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee eeeeeeeeeeeeeeeeeeeeeeeeee eeeeeeeeeeeeeeeeeeeeeeeeeee kksdmcksdc ksdc kc ksdcn skodcklsdmcklsmdklcmsdklcmklsdmclksmcksmd
		</div>

		<ul class="user">By <li><a href="">User</a></li>
		<li class="category"><a href="">Category</a></li>
		</ul>
		<br>
		<a href="" class="btn btn-success detail">Details</a><a href="" class="btn btn-info detail-ex"><i class="fa fa-comment"></i>&nbsp;0</a><a href="" class="btn btn-default detail-ex"><i class="fa fa-eye"></i>&nbsp;0</a>
	</div>
	<div class="item">
		<div class="col-md-3 featured-img-s"><a href=""><img src="public/images/android.png"></a></div>

		<div class="col-md-9 post-desc-home">
		<a href="#" class="post-title-home">THis is the title</a>
		thisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the caption ende nedn eeeeeeeeee eeeeeeeeeeeee eeeeeeeeeeeeeeeee  eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee eeeeeeeeeeeeeeeeeeeeeeeeee eeeeeeeeeeeeeeeeeeeeeeeeeee kksdmcksdc ksdc kc ksdcn skodcklsdmcklsmdklcmsdklcmklsdmclksmcksmd
		</div>

		<ul class="user">By <li><a href="">User</a></li>
		<li class="category"><a href="">Category</a></li>
		</ul>
		<br>
		<a href="" class="btn btn-success detail">Details</a><a href="" class="btn btn-info detail-ex"><i class="fa fa-comment"></i>&nbsp;0</a><a href="" class="btn btn-default detail-ex"><i class="fa fa-eye"></i>&nbsp;0</a>
	</div>
		<div class="item">
		<div class="col-md-3 featured-img-s"><a href=""><img src="public/images/android.png"></a></div>

		<div class="col-md-9 post-desc-home">
		<a href="#" class="post-title-home">THis is the title</a>
		thisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the captionthisis the caption ende nedn eeeeeeeeee eeeeeeeeeeeee eeeeeeeeeeeeeeeee  eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee eeeeeeeeeeeeeeeeeeeeeeeeee eeeeeeeeeeeeeeeeeeeeeeeeeee kksdmcksdc ksdc kc ksdcn skodcklsdmcklsmdklcmsdklcmklsdmclksmcksmd
		</div>

		<ul class="user">By <li><a href="">User</a></li>
		<li class="category"><a href="">Category</a></li>
		</ul>
		<br>
		<a href="" class="btn btn-success detail">Details</a><a href="" class="btn btn-info detail-ex"><i class="fa fa-comment"></i>&nbsp;0</a><a href="" class="btn btn-default detail-ex"><i class="fa fa-eye"></i>&nbsp;0</a>
	</div>

</div>


<div class="col-md-3 post-sidebar">
	<div class="item">
	<span class="title">Related link</span>
		<ul>
		<li><a href="">Sidebar Sidebar Sidebar Sidebar</a></li>
		<li><a href="">Sidebar Sidebar Sidebar</a></li>
		</ul>
	</div>
	<div class="item">
		<span class="title">
			Ads
		</span>
		<a href=""><img src="public/images/android.png"></a>
	</div>
</div>